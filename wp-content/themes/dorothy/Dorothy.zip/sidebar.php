<?php if ( is_active_sidebar( 'right-widget' ) ) : ?>
<aside class="aside" role="complementary">

  <?php dynamic_sidebar( 'right-widget' ); ?>

</aside><!-- .aside -->
<?php endif; ?>