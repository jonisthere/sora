/*
 * Bones Scripts File
 * Author: Eddie Machado
 *
 * This file should contain any js scripts you want to add to the site.
 * Instead of calling it in the header or throwing it inside wp_head()
 * this file will be called automatically in the footer so as not to
 * slow the page load.
 *
 * There are a lot of example functions and tools in here. If you don't
 * need any of it, just remove it. They are meant to be helpers and are
 * not required. It's your world baby, you can do whatever you want.
*/


/*
 * Get Viewport Dimensions
 * returns object with viewport dimensions to match css in width and height properties
 * ( source: http://andylangton.co.uk/blog/development/get-viewport-size-width-and-height-javascript )
*/
function updateViewportDimensions() {
	var w=window,d=document,e=d.documentElement,g=d.getElementsByTagName('body')[0],x=w.innerWidth||e.clientWidth||g.clientWidth,y=w.innerHeight||e.clientHeight||g.clientHeight;
	return { width:x,height:y };
}
// setting the viewport width
var viewport = updateViewportDimensions();


/*
 * Throttle Resize-triggered Events
 * Wrap your actions in this function to throttle the frequency of firing them off, for better performance, esp. on mobile.
 * ( source: http://stackoverflow.com/questions/2854407/javascript-jquery-window-resize-how-to-fire-after-the-resize-is-completed )
*/
var waitForFinalEvent = (function () {
	var timers = {};
	return function (callback, ms, uniqueId) {
		if (!uniqueId) { uniqueId = "Don't call this twice without a uniqueId"; }
		if (timers[uniqueId]) { clearTimeout (timers[uniqueId]); }
		timers[uniqueId] = setTimeout(callback, ms);
	};
})();

// how long to wait before deciding the resize has stopped, in ms. Around 50-100 should work ok.
var timeToWaitForLast = 100;


/*
 * Here's an example so you can see how we're using the above function
 *
 * This is commented out so it won't work, but you can copy it and
 * remove the comments.
 *
 *
 *
 * If we want to only do it on a certain page, we can setup checks so we do it
 * as efficient as possible.
 *
 * if( typeof is_home === "undefined" ) var is_home = $('body').hasClass('home');
 *
 * This once checks to see if you're on the home page based on the body class
 * We can then use that check to perform actions on the home page only
 *
 * When the window is resized, we perform this function
 * $(window).resize(function () {
 *
 *    // if we're on the home page, we wait the set amount (in function above) then fire the function
 *    if( is_home ) { waitForFinalEvent( function() {
 *
 *	// update the viewport, in case the window size has changed
 *	viewport = updateViewportDimensions();
 *
 *      // if we're above or equal to 768 fire this off
 *      if( viewport.width >= 768 ) {
 *        console.log('On home page and window sized to 768 width or more.');
 *      } else {
 *        // otherwise, let's do this instead
 *        console.log('Not on home page, or window sized to less than 768.');
 *      }
 *
 *    }, timeToWaitForLast, "your-function-identifier-string"); }
 * });
 *
 * Pretty cool huh? You can create functions like this to conditionally load
 * content and other stuff dependent on the viewport.
 * Remember that mobile devices and javascript aren't the best of friends.
 * Keep it light and always make sure the larger viewports are doing the heavy lifting.
 *
*/

/*
 * We're going to swap out the gravatars.
 * In the functions.php file, you can see we're not loading the gravatar
 * images on mobile to save bandwidth. Once we hit an acceptable viewport
 * then we can swap out those images since they are located in a data attribute.
*/
function loadGravatars() {
  // set the viewport using the function above
  viewport = updateViewportDimensions();
  // if the viewport is tablet or larger, we load in the gravatars
  if (viewport.width >= 768) {
  jQuery('.comment img[data-gravatar]').each(function(){
    jQuery(this).attr('src',jQuery(this).attr('data-gravatar'));
  });
	}
} // end function


/*
 * Put all your regular jQuery in here.
*/
jQuery(document).ready(function($) {

  /*
   * Let's fire off the gravatar function
   * You can remove this if you don't need it
  */
  loadGravatars();


    var divs = $('.social');

    divs.hide();
$(window).scroll(function(){
   if($(window).scrollTop()<200){
         divs.stop(true,true).fadeIn("fast");
   } else {
         divs.stop(true,true).fadeOut("fast");
   }
});

$('.entry-content').hide();
$('.main-container').css({
  'position':'relative',
  'left':'60%',
});
  Height = jQuery( window ).height();
    Width = jQuery( window ).width();
console.log(Width);

    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
      } else {

  $(document).ready(function() {
     

     $('#main-area').fullpage({
        anchors: ['section-1','section-2','section-3','section-4','section-5','section-6'],
        afterLoad: function(anchorLink, index){
          $('.active-section').removeClass('active-section');
          //section 2
          if(index == 1){
            $('.header-banner-color').css({
                'background':'#eaefb7'
              });
            $('.menu').find('.active-section').removeClass('.active-section');
            $('a[href^="#section-home"]').parent().addClass('active-section');
          }
          if(index == 2){
            //moving the image
            $('.section-2').find('.entry-content').fadeIn(1000);
            $('.section-2').find('.main-container').delay(0).animate({
              left: '0%'
            }, 500);
            $('.header-banner-color').css({
                'background':'#ddead9'
              });
            $('.menu').find('.active-section').removeClass('active-section');
            $('a[href^="#section-2"]').parent().addClass('active-section');
          }
          if(index == 3){
            //moving the image
            $('.section-3').find('.entry-content').fadeIn(1000);
            $('.section-3').find('.main-container').delay(0).animate({
              left: '0%'
            }, 500);
            $('.header-banner-color').css({
                'background':'#ffffe6'
              });
            $('a[href^="#section-3"').parent().addClass('active-section');
          }
          if(index == 4){
            //moving the image
            $('.section-4').find('.entry-content').fadeIn(1000);
            $('.section-4').find('.main-container').delay(0).animate({
              left: '0%'
            }, 500);
            $('.header-banner-color').css({
                'background':'#fcf8ee'
              });
            $('a[href^="#section-4"').parent().addClass('active-section');
          }

          if(index == 5){
            //moving the image
            $('.section-5').find('.entry-content').fadeIn(1000);
            $('.section-5').find('.main-container').delay(0).animate({
              left: '0%'
            }, 500);
            $('.header-banner-color').css({
                'background':'#ffffe6'
              });
            $('a[href^="#section-5"]').parent().addClass('active-section');
          }
          if(index == 6){
            //moving the image
            $('.section-6').find('.entry-content').fadeIn(1000);
            $('.section-6').find('.main-container').delay(0).animate({
              left: '0%'
            }, 500);
            $('.header-banner-color').css({
                'background':'#eaefb7'
              });
            $('a[href^="#section-6"]').parent().addClass('active-section');
          }
          
          //section 3
         /* if(anchorLink == '3rdPage'){
            //moving the image
            $('#section2').find('.intro').delay(500).animate({
              left: '0%'
            }, 1500, 'easeOutExpo');
          }
          */
        }
      });
    });


  }

  /*$(".tothetop").click(function() {
     if ($('#sticky').hasClass('stick')){
        scrollToAnchor('top', 0);
      } else {
        scrollToAnchor('top', 0);
      } 
  });*/

/*$("#main-area").scrollview({
      sectionContainer: ".page-area-section",
        responsiveFallback: 600,
        loop: true,
        direction : 'vertical',
        beforeMove: function(){
            console.log('sfffdf');

            if($('.active').hasClass('section-1')) {
                
                $('.header').css(
                  {
                    background: "#FF0000",
                    
                  }
                  );
              }
        },

    }, function(){
      console.log('aaaadfsfdsfsdf');
    })
*/
/*$( "body" ).change(function() {
  alert( "Handler for .change() called." );
});
if($('.active').hasClass('section-1')) {
  console.log('sfffdf');
  $('.header').css(
    {
      background: "#FF0000",
      
    }
    );
}

if($('.active').hasClass('section-2')) {
  console.log('sfffdf');
  $('.header').css(
    {
      background: "#333333",
    }
  );
}



*/


// Load this script when page loads
$(document).ready(function(){

 // Set up a listener so that when anything with a class of 'tab' 
 // is clicked, this function is run.
 $('.tab').click(function () {

  // Remove the 'active' class from the active tab.
  $('li.active')
    .removeClass('active');
    
  // Add the 'active' class to the clicked tab.
  $(this).parent().addClass('active');

  // Remove the 'tab_contents_active' class from the visible tab contents.
  $('div.tab_contents_active')
    .removeClass('tab_contents_active');

  // Add the 'tab_contents_active' class to the associated tab contents.
  $(this.rel).addClass('tab_contents_active');

 });
});




$('#menu').slicknav({
    prependTo:'body',
    closeOnClick: 'true'
});


$(function() {

  //preload images 
  var lips = $('<img />').attr('src', 'http://localhost/sora/wp-content/themes/sora%20new/library/images/treatments/lips.png');
  var forehead = $('<img />').attr('src', 'http://localhost/sora/wp-content/themes/sora%20new/library/images/treatments/forehead.png');
  var nosebridge = $('<img />').attr('src', 'http://localhost/sora/wp-content/themes/sora%20new/library/images/treatments/nose-bridge.png');
  var smokerslines = $('<img />').attr('src', 'http://localhost/sora/wp-content/themes/sora%20new/library/images/treatments/smokers-lines.png');
  var TopNosegarbella = $('<img />').attr('src', 'http://localhost/sora/wp-content/themes/sora%20new/library/images/treatments/Top-Nose-garbella.png');
  var cheeks = $('<img />').attr('src', 'http://localhost/sora/wp-content/themes/sora%20new/library/images/treatments/cheeks.png');
  var eyewrinkle = $('<img />').attr('src', 'http://localhost/sora/wp-content/themes/sora%20new/library/images/treatments/eye-wrinkle.png');
  var nasiolabial = $('<img />').attr('src', 'http://localhost/sora/wp-content/themes/sora%20new/library/images/treatments/nasio-labial.png');
  
  var lips_content = $('.Lips').html();
  var eye_wrinkle_content = $('.eye_wrinkle').html();
  $(".treatment-overlays").mousemove( function(e) {
    var offset = $(this).offset();
    var relativeX = (e.pageX - offset.left);
    var relativeY = (e.pageY - offset.top);
    console.log("X: " + relativeX + "  Y: " + relativeY);

    
    if (relativeX > 70 && relativeX < 230 && relativeY < 140  ) {
      $('.treatment-overlays img').replaceWith(forehead);
    }
    if (relativeX < 170 && relativeX > 130 && relativeY > 141 && relativeY < 201  ) {
      $('.treatment-overlays img').replaceWith(TopNosegarbella);
    }
    if ((relativeX < 120 && relativeX > 60 && relativeY > 191 && relativeY < 241) || (relativeX < 230 && relativeX > 180 && relativeY > 191 && relativeY < 241)   ) {
      $('.treatment-overlays img').replaceWith(cheeks);
    }
    if ((relativeX < 60 && relativeX > 40 && relativeY > 180 && relativeY < 210) || (relativeX < 280 && relativeX > 230 && relativeY > 180 && relativeY < 210)   ) {
      $('.treatment-overlays img').replaceWith(eyewrinkle); 
      $('.treatment-content-area').html(eye_wrinkle_content)
    }
    if (relativeX < 170 && relativeX > 130 && relativeY > 204 && relativeY < 270  ) {
      $('.treatment-overlays img').replaceWith(nosebridge);
    }
    if (relativeX < 170 && relativeX > 130 && relativeY > 271 && relativeY < 300  ) {
      $('.treatment-overlays img').replaceWith(smokerslines);
    }
    
    if ((relativeX < 114 && relativeX > 100 && relativeY > 270 && relativeY < 300) || (relativeX < 204 && relativeX > 185 && relativeY > 270 && relativeY < 300) ) {
      $('.treatment-overlays img').replaceWith(nasiolabial);
    }
    if (relativeX < 170 && relativeX > 130 && relativeY > 301 && relativeY < 340 ) {
      $('.treatment-overlays img').replaceWith(lips);
      //$('.treatment-content-area').fadeOut();
      $('.treatment-content-area').html(lips_content)
    }
  });
});

}); /* end of as page load scripts */

/*
 * jQuery Anystretch
 * Version 1.0
 * https://github.com/danmillar/jquery-anystretch
 *
 * Add a dynamically-resized background image to the body
 * of a page or any other block level element within it
 *
 * Copyright (c) 2012 Dan Millar (@danmillar / decode.uk.com)
 * Dual licensed under the MIT and GPL licenses.
 *
 * This is a fork of jQuery Backstretch (v1.2)
 * Copyright (c) 2011 Scott Robbin (srobbin.com)
*/

;(function($) {
    
    $.fn.anystretch = function(src, options, callback) {
        return this.each(function(i){
        
            var defaultSettings = {
                centeredX: true,         // Should we center the image on the X axis?
                centeredY: true,         // Should we center the image on the Y axis?
                speed: 0,                // fadeIn speed for background after image loads (e.g. "fast" or 500)
                elPosition: 'relative',  // position of containing element when not being added to the body
                useInnerWidth: false     // set to true if dealing with elements with borders 
            },
            el = $(this),
            isBody = (el.get(0).tagName == undefined) ? true : false, // Decide whether anystretch is being called on an element or not
            container = isBody ? $('.anystretch') : el.children(".anystretch"),
            settings = container.data("settings") || defaultSettings, // If this has been called once before, use the old settings as the default
            existingSettings = container.data('settings'),
            imgRatio, bgImg, bgWidth, bgHeight, bgOffset, bgCSS;
            
            // Extend the settings with those the user has provided
            if(options && typeof options == "object") $.extend(settings, options);
            
            // Just in case the user passed in a function without options
            if(options && typeof options == "function") callback = options;
        
            // Initialize
            $(document).ready(_init);
      
            // For chaining
            return this;
        
            function _init() {
                // Prepend image, wrapped in a DIV, with some positioning and zIndex voodoo
                if(src) {
                    var img;
                    
                    if(!isBody) {
                        // If not being added to the body set position to elPosition (default: relative) to keep anystretch contained
                        el.css({position: settings.elPosition, background: "none"});
                    }
                    
                    // If this is the first time that anystretch is being called
                    if(container.length == 0) {
                        container = $("<div />").attr("class", "anystretch")
                                                .css({left: 0, top: 0, position: (isBody ? "fixed" : "absolute"), overflow: "hidden", zIndex: (isBody ? -999999 : -999998), margin: 0, padding: 0, height: "100%", width: "100%"});
                    } else {
                        // Prepare to delete any old images
                        container.find("img").addClass("deleteable");
                    }
    
                    img = $("<img />").css({position: "absolute", display: "none", margin: 0, padding: 0, border: "none", zIndex: -999999})
                                      .bind("load", function(e) {                                          
                                          var self = $(this),
                                              imgWidth, imgHeight;
        
                                          self.css({width: "auto", height: "auto"});
                                          imgWidth = this.width || $(e.target).width();
                                          imgHeight = this.height || $(e.target).height();
                                          imgRatio = imgWidth / imgHeight;
    
                                          _adjustBG(function() {
                                              self.fadeIn(settings.speed, function(){
                                                  // Remove the old images, if necessary.
                                                  container.find('.deleteable').remove();
                                                  // Callback
                                                  if(typeof callback == "function") callback();
                                              });
                                          });
                                          
                                      })
                                      .appendTo(container);
                     
                    // Append the container to the body, if it's not already there
                    if(el.children(".anystretch").length == 0) {
                        if(isBody) {
                            $('body').append(container);
                        } else {
                            el.append(container);
                        }
                    }
                    
                    // Attach the settings
                    container.data("settings", settings);
                        
                    img.attr("src", src); // Hack for IE img onload event
                    
                    // Adjust the background size when the window is resized or orientation has changed (iOS)
                    $(window).resize(_adjustBG);
                }
            }
                
            function _adjustBG(fn) {
                try {
                    bgCSS = {left: 0, top: 0};
                    bgWidth = _width();
                    bgHeight = bgWidth / imgRatio;
    
                    // Make adjustments based on image ratio
                    // Note: Offset code provided by Peter Baker (http://ptrbkr.com/). Thanks, Peter!
                    if(bgHeight >= _height()) {
                        bgOffset = (bgHeight - _height()) /2;
                        if(settings.centeredY) $.extend(bgCSS, {top: "-" + bgOffset + "px"});
                    } else {
                        bgHeight = _height();
                        bgWidth = bgHeight * imgRatio;
                        bgOffset = (bgWidth - _width()) / 2;
                        if(settings.centeredX) $.extend(bgCSS, {left: "-" + bgOffset + "px"});
                    }
    
                    container.children("img:not(.deleteable)").width( bgWidth ).height( bgHeight )
                                                       .filter("img").css(bgCSS);
                } catch(err) {
                    // IE7 seems to trigger _adjustBG before the image is loaded.
                    // This try/catch block is a hack to let it fail gracefully.
                }
          
                // Executed the passed in function, if necessary
                if (typeof fn == "function") fn();
            }
            
            function _width() {
                return isBody || settings.useInnerWidth ? el.width() : el.outerWidth();
            }
            
            function _height() {
                return isBody || settings.useInnerWidth ? el.height() : el.outerHeight();
            }
            
        });
    };
    
    $.anystretch = function(src, options, callback) {
        var el = ("onorientationchange" in window) ? $(document) : $(window); // hack to acccount for iOS position:fixed shortcomings
        
        el.anystretch(src, options, callback);
    };
  
})(jQuery);
