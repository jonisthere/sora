<?php 
if( isset( $template_args ) ) {
	extract( $template_args );
}

$section = new WP_Query(array(
	'post_type'=>'page',
	'post_status'=>'publish', 
	'posts_per_page'=>1, 
	'page_id'=>$id
));	
?>
<?php while ($section->have_posts()) : $section->the_post(); ?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">
		<section class="entry-content">
			<h2 class="section-title"><?php the_title(); ?></h2>
			<?php 
			 the_content();
			?>
			  
			<div class="treatment-tabs">
			</div>
			<?php $fields = array (
								'Lips' => 'lips_text',
								'eye_wrinkle' => 'eye_wrinkle_text',
								'forehead' =>'forehead_text',
								'nasio_labial' =>'nasio_labial_text',
								'nose_bridge' =>'nose_bridge_text',
								'smokers_lines' =>'smokers_lines_text',
								'top_nose_garbella' => 'top_nose_garbella_text',
							); ?>
			

	        <div class="tab_contents_container">
	        	<ul class="tabs">
			        <?php $x = 1;
				foreach ($fields as $key => $value) { ?>
					<li <?php echo  ($x == 1 ? 'class="active"' : '') ?>>
			          <a href="#" rel="#tab_<?php echo $x ?>_contents" class="tab"><?php echo get_field($key); ?></a>
			        </li>
			    <?php $x++;	}	?>
		        <div style="clear:both"></div>
		        </ul>
			     
			        <!-- Tab 1 Contents -->
		        <?php $x = 1;
			foreach ($fields as $key => $value) {
			if( get_field($key)) { ?>
			<div id="tab_<?php echo $x ?>_contents" class="tab_contents <?php echo  ($x == 1 ? 'class="tab_contents_active"' : '') ?>">
	          <div class="<?php echo $key ?> ">
					<h2><?php echo get_field($key); ?></h2>
					<p><?php echo get_field($value); ?></p>
				</div>	
	        </div>
		<?php	$x++; }		
			} ?>

		        
			</div>

			<div class="">
			
			</div>
		</section>
	</article>											
<?php endwhile; ?>


